def action():
  print("Work:action")

if __name__ == '__main__':  # Только когда запускается,
  action()  # а не импортируется
