print("__init__ mymodule")
