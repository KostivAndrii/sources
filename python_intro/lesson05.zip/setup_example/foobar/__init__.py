def f():
  print("I'm the f")