#django-admin startproject mysite
#python manage.py migrate
#python manage.py createsuperuser
#python manage.py runserver